To run the program, type "make" to compile everything and then type "java ExamTester".
I used bert32 to test this and it works fine there.
You can type "make clean" to get rid of the class files you create when compiling.

I didn't ever close my Scanner because when I did that, my program wouldn't run on bert32.
If you compile my code on an IDE you will get warnings for this but it'll run fine regardless.

Also, you'll have to type out the full answer for all of my questions.
That is, you can't answer my multiple choice questions by just inputting "A" or "B" or whatever.
But, my answer comparisons are case insensitive so you don't need to worry about capitalization in your answers.

Also also, I changed the return type of getAnswerFromStudent() in MCSAQuestion from Answer to void.

Also also also, I wasn't sure what to put for the getNewAnswer() function in MCSA question, but I needed to return an Answer...
So I just made a new Answer and returned that I guess. That function is never called anyway.

Answer Key:
How many hours do you study in a day? "9"

What is the radius of your bar of soap in meters in your bathroom? "15ft"

How much work is required to pump 4 feet of water out of a cylindrical tank with a spout exceeding 3m? "Soccer"

Who is my dad? "Troy.Patrick{}"